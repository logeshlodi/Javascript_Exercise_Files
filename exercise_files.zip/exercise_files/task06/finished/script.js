// function add(a, b){
//     var sum = a + b;
//     return sum;
// }

// var addResult = add(5, 10);
// console.log(addResult);


// var addFunc = function(a,b){ 
//     return a+b;
// };

// console.log(addFunc(5,10));

(function(a,b){
    console.log(a+b);
})(5,10);
