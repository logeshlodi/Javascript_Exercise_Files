var myVariable = 3; 
console.log(typeof myVariable);

var myString = "Hello World!";
console.log(typeof myString);

var myBool = true;
console.log(typeof myBool);

var animals = ["cat", "dog", "elephant"];
console.log(animals[1]);

var mixArray = [4, "cat", false];
console.log(mixArray);

mixArray[1] = "dog";
console.log(mixArray);

var x = 5;
var y = 10;

var sum = x + y; 
console.log(sum);

var mult = x * y;
console.log(mult);

var sub = x - y;
console.log(sub);

var stringAdd = myString + x ;
console.log(stringAdd);

var z = "3";
var m = 4;

var newSum = z + m;
console.log(newSum);